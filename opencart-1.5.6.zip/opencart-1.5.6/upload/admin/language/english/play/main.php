<?php
$_['lang_heading']                      = 'Play.com (Europe)';