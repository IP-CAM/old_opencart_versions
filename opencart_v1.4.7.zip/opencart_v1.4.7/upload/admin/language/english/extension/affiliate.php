<?php
// Heading
$_['heading_title']  = 'Affiliates';

// Text
$_['text_install']   = 'Install';
$_['text_uninstall'] = 'Uninstall';

// Column
$_['column_name']    = 'Affiliate Name';
$_['column_status']  = 'Status';
$_['column_action']  = 'Action';
?>