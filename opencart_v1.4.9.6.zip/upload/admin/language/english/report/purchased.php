<?php
// Heading
$_['heading_title']   = 'Products Purchased Report';

// Column
$_['column_name']     = 'Product Name';
$_['column_model']    = 'Model';
$_['column_quantity'] = 'Quantity';
$_['column_total']    = 'Total';
?>
